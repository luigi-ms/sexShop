<?php
	interface IPessoa{
		function cadastrar();
		function remover();
		function alterar();
		function listar();
	}
?>